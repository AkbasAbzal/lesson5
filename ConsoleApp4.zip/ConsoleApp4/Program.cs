﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {

            /*Console.WriteLine("Введите строку");
            string filename = "text.txt";
            File.WriteAllText(filename, Console.ReadLine()); 
            string fileText = File.ReadAllText(filename);
            Console.WriteLine(fileText); 
            */
            /*
            var todayDate = DateTime.Now;
            string filename = "startup.txt";
            File.WriteAllText(filename, todayDate.ToString());
            string fileText = File.ReadAllText(filename);
            Console.WriteLine(fileText);
            */
            /*
            const string file = "test.bin";

            Console.WriteLine("Input a case of number's in range [0..255] separating with whitespace");
            var input = Console.ReadLine()?.Split(' ', (char)StringSplitOptions.RemoveEmptyEntries);

            if (input is null)
            {
                Console.WriteLine("incorrect input");
                return;
            }

            var array = new byte[input.Length];
            for (var i = 0; i < array.Length; i++)
            {
                if (!byte.TryParse(input[i], out var number))
                {
                    Console.WriteLine($"Incorrect number {input[i]}");
                    return;
                }

                array[i] = number;
            }

            using (var bw = new BinaryWriter(File.OpenWrite(file)))
            {
                bw.Write(array);
                bw.Flush();
            }

            Console.WriteLine("i read it for you");
            byte[] newData;
            using (var br = new BinaryReader(File.OpenRead(file)))
            {
                newData = br.ReadBytes(array.Length);
            }

            for (var i = 0; i < newData.Length; i++)
            {
                Console.Write(newData[i] + " ");
            }
            */
        }
    }
}        
